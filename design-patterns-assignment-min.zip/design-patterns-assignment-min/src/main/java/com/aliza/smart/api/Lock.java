package com.aliza.smart.api;

public interface Lock {
    String brand();
    String name();
    void loadUsage();
    double usage();
}
