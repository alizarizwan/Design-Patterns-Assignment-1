package com.aliza.smart.api;

public interface Bulb {
    String brand();
    String name();
    void loadUsage();
    double usage();
}
